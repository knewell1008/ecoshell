Ecoshell Solutions icons

Four individual transparent SVG files.
Colour: #7FC492. Stroke: 1.6 on a 24 x 24 viewBox.
No fills, backgrounds, shadows or gradients.
Use at 24-32 px on the existing #1A3629 dark tiles.
Material: resin drop. Manufacturing: two-part mold.
Packaging: lidded jar. Custom: plus in a rounded box.
